
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindSymbolAction(compId,symbolName,"creationComplete",function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_Clear_button}","click",function(sym,e){sym.play();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){sym.stop();});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${_play_again}","click",function(sym,e){sym.play(2000);});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'group_laugh2'
(function(symbolName){})("group_laugh2");
//Edge symbol end:'group_laugh2'

//=========================================================

//Edge symbol: 'play_button'
(function(symbolName){})("play_button");
//Edge symbol end:'play_button'

//=========================================================

//Edge symbol: 'play_again'
(function(symbolName){})("play_again");
//Edge symbol end:'play_again'
})(jQuery,AdobeEdge,"EDGE-101606392");