// This code, coupled with a JQuery library, allows any BlackBoard page to fit full screen (no white border padding) and eliminate the extra space at the bottom of pages.
(function(){
	function mysize (offset)
	{
		if (jQuery) 
		{
			$('#containerdiv',parent.document).css("padding","0");
		
			$('#cleanSlate',parent.document).load(
				function()
					{ 
						$('#cleanSlate',parent.document).height( $("html").height()+offset );
					}
			);
		}
	}
	mysize(200); //Change this value to get more or less space at the bottom of the course pageterm
})();



