function printPage(){
	window.print();
}
document.getElementById("printBtn").addEventListener("click", printPage);

function dynamicPadding(){
	var $windowHeight = window.innerHeight;
	var $contentHeight = document.getElementsByClassName("container")[0].offsetHeight;
	
	if ($contentHeight > $windowHeight){
		document.getElementsByClassName("container")[0].style.paddingBottom  = "0px";
	}

}
dynamicPadding();